import logo from './logo.svg';
import './App.css';
import React from "react";
import DrillingDashboard from "./DrillingDashboard";
import WellSlideshow from "./WellSlideshow";
import WellHistory from "./WellHistory";
import { Routes, Route } from "react-router-dom";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

function App() {
  return (
    <div className="App">
      <div className="oil-rig-bg"></div>
      <div className="dashboard-container">
        <h1>Drilling Operations Dashboard</h1>
        <Routes>
          <Route path="/" element={<DrillingDashboard />} />
          <Route path="/slideshow" element={<WellSlideshow />} />
          <Route path="/history/:wellId" element={<WellHistory />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
