import React from 'react';

const provinceImageMap = {
  'Punjab': 'punjab.png',
  'Sindh': 'sindh.png',
  'Khyber Pakhtunkhwa': 'kpk.png',
  'Balochistan': 'balochistan.png',
  'Gilgit-Baltistan': 'gilgit_baltistan.jpg',
  'Azad Jammu and Kashmir': 'ajk.png',
  'Islamabad Capital Territory': 'ict.png',
};

function ProvinceImage({ province }) {
  if (!province || !provinceImageMap[province]) return null;
  return (
    <div style={{
      background: 'linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%)',
      borderRadius: '12px',
      padding: '20px',
      boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
      width: 340,
      height: 340,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
    }}>
      <h3 style={{
        marginBottom: '16px',
        color: '#1976d2',
        fontSize: '18px',
        fontWeight: 'bold',
        textAlign: 'center'
      }}>
        {province} Province
      </h3>
      <img
        src={`/maps/${provinceImageMap[province]}`}
        alt={province}
        style={{
          width: 260,
          height: 'auto',
          borderRadius: 8,
          border: '2px solid #e0e0e0',
          boxShadow: '0 4px 16px rgba(25, 118, 210, 0.15)'
        }}
        loading="lazy"
        onError={e => {
          e.target.onerror = null;
          e.target.src = '/maps/ajk.png';
        }}
      />
    </div>
  );
}

export default ProvinceImage; 