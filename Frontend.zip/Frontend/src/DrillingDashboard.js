import React, { useEffect, useState, useMemo, useCallback } from "react";
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';

import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import Slider from "react-slick";
import WellPieChartBox from "./WellPieChartBox";
import FiscalYearDisplay from "./FiscalYearDisplay";
import { useNavigate } from "react-router-dom";
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import ProvinceImage from "./ProvinceImage";
import WellMap from "./WellMap";
import WellSelector from "./WellSelector";
import WellSummaryCard from "./WellSummaryCard";
import WellCharts from "./WellCharts";
import WellSlideshow from "./WellSlideshow";

// Separate AddWellModal component to prevent re-renders
const AddWellModal = ({ isOpen, onClose, onSubmit, initialData = {} }) => {
  const [formData, setFormData] = useState({
    WellName: '',
    RigName: '',
    BlockName: '',
    Longitude: '',
    Latitude: '',
    SpudDate: '',
    TargetDepth: '',
    PlannedAFEDaysDrilling: '',
    PlannedAFEDaysActual: '',
    ...initialData
  });
  const [error, setError] = useState(null);

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    setError(null);
    try {
      await onSubmit(formData);
      setFormData({
        WellName: '',
        RigName: '',
        BlockName: '',
        Longitude: '',
        Latitude: '',
        SpudDate: '',
        TargetDepth: '',
        PlannedAFEDaysDrilling: '',
        PlannedAFEDaysActual: ''
      });
      onClose();
    } catch (err) {
      setError(err.message);
    }
  };

  if (!isOpen) return null;

  return (
    <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.4)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <div style={{ background: '#fff', padding: 32, borderRadius: 12, minWidth: 400, maxWidth: 600, boxShadow: '0 4px 32px rgba(25, 118, 210, 0.20)', maxHeight: '90vh', overflowY: 'auto' }}>
        <h2 style={{ marginBottom: 16, color: '#23234c' }}>Add New Well</h2>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <input 
            placeholder="Well Name *" 
            type="text"
            value={formData.WellName} 
            onChange={e => handleInputChange('WellName', e.target.value)} 
            style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc' }} 
          />
          <input 
            placeholder="Rig Name *" 
            type="text"
            value={formData.RigName} 
            onChange={e => handleInputChange('RigName', e.target.value)} 
            style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc' }} 
          />
          <input 
            placeholder="Block Name *" 
            type="text"
            value={formData.BlockName} 
            onChange={e => handleInputChange('BlockName', e.target.value)} 
            style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc' }} 
          />
          <input 
            placeholder="Spud Date" 
            type="date"
            value={formData.SpudDate} 
            onChange={e => handleInputChange('SpudDate', e.target.value)} 
            style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc' }} 
          />
          <input 
            placeholder="Longitude" 
            type="number"
            step="0.0001"
            value={formData.Longitude} 
            onChange={e => handleInputChange('Longitude', e.target.value)} 
            style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc' }} 
          />
          <input 
            placeholder="Latitude" 
            type="number"
            step="0.0001"
            value={formData.Latitude} 
            onChange={e => handleInputChange('Latitude', e.target.value)} 
            style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc' }} 
          />
          <input 
            placeholder="Target Depth (M)" 
            type="number"
            value={formData.TargetDepth} 
            onChange={e => handleInputChange('TargetDepth', e.target.value)} 
            style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc' }} 
          />
          <input 
            placeholder="Planned AFE Days (Drilling)" 
            type="number"
            value={formData.PlannedAFEDaysDrilling} 
            onChange={e => handleInputChange('PlannedAFEDaysDrilling', e.target.value)} 
            style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc' }} 
          />
          <input 
            placeholder="Planned AFE Days (Actual)" 
            type="number"
            value={formData.PlannedAFEDaysActual} 
            onChange={e => handleInputChange('PlannedAFEDaysActual', e.target.value)} 
            style={{ padding: 8, borderRadius: 6, border: '1px solid #ccc' }} 
          />
        </div>
        <div style={{ marginTop: 12, fontSize: '12px', color: '#666' }}>
          * Required fields
        </div>
        {error && <div style={{ color: 'red', marginTop: 8 }}>{error}</div>}
        <div style={{ marginTop: 20, display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={{ background: '#eee', color: '#23234c', border: 'none', borderRadius: 6, padding: '8px 18px', fontWeight: 600 }}>Cancel</button>
          <button 
            onClick={handleSubmit} 
            disabled={!formData.WellName || !formData.RigName || !formData.BlockName}
            style={{ 
              background: !formData.WellName || !formData.RigName || !formData.BlockName ? '#ccc' : '#388e3c', 
              color: '#fff', 
              border: 'none', 
              borderRadius: 6, 
              padding: '8px 18px', 
              fontWeight: 600,
              cursor: !formData.WellName || !formData.RigName || !formData.BlockName ? 'not-allowed' : 'pointer'
            }}
          >
            Add Well
          </button>
        </div>
      </div>
    </div>
  );
};

// Fix default marker icon issue with webpack
if (L.Icon.Default && L.Icon.Default.mergeOptions) {
  delete L.Icon.Default.prototype._getIconUrl;
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
    iconUrl: require('leaflet/dist/images/marker-icon.png'),
    shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
  });
}

function DrillingDashboard() {
  const [operations, setOperations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedWell, setSelectedWell] = useState("");
  const [editMode, setEditMode] = useState(false);
  const [editData, setEditData] = useState({});
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);
  const [selectedProvince, setSelectedProvince] = useState("");
  const [history, setHistory] = useState([]);
  const [showHistory, setShowHistory] = useState(false);
  const navigate = useNavigate();
  const [emailStatus, setEmailStatus] = useState('');
  const [emailLoading, setEmailLoading] = useState(false);
  const [showSlideshow, setShowSlideshow] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const [deletingWellId, setDeletingWellId] = useState(null);
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [selectedWellsToDelete, setSelectedWellsToDelete] = useState([]);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [deleteError, setDeleteError] = useState(null);
  const [showPastWellsModal, setShowPastWellsModal] = useState(false);
  const [pastWells, setPastWells] = useState([]);
  const [pastWellsLoading, setPastWellsLoading] = useState(false);

  // Function to determine province from block name - moved before useMemo
  const getProvinceFromBlock = useCallback((blockName) => {
    if (!blockName) return "Unknown";
    
    const blockLower = blockName.toLowerCase();
    
    if (blockLower.includes('punjab') || blockLower.includes('sargodha') || blockLower.includes('chakwal')) {
      return "Punjab";
    } else if (blockLower.includes('sindh') || blockLower.includes('karachi') || blockLower.includes('hyderabad')) {
      return "Sindh";
    } else if (blockLower.includes('kpk') || blockLower.includes('peshawar') || blockLower.includes('swat')) {
      return "Khyber Pakhtunkhwa";
    } else if (blockLower.includes('balochistan') || blockLower.includes('quetta') || blockLower.includes('sui')) {
      return "Balochistan";
    } else if (blockLower.includes('gilgit') || blockLower.includes('baltistan')) {
      return "Gilgit-Baltistan";
    } else if (blockLower.includes('kashmir') || blockLower.includes('ajk')) {
      return "Azad Jammu and Kashmir";
    } else if (blockLower.includes('islamabad') || blockLower.includes('ict')) {
      return "Islamabad Capital Territory";
    } else {
      return "Unknown";
    }
  }, []);

  // Function to calculate weekly meters drilled
  const calculateWeeklyMetersDrilled = useCallback((mDrld, lastUpdated) => {
    if (!mDrld || !lastUpdated) return 0;
    
    const today = new Date();
    const lastUpdate = new Date(lastUpdated);
    const daysSinceLastUpdate = Math.floor((today - lastUpdate) / (1000 * 60 * 60 * 24));
    
    // Calculate meters per day (assuming daily drilling)
    const metersPerDay = mDrld / Math.max(daysSinceLastUpdate, 1);
    
    // Calculate days since Monday (0 = Monday, 6 = Sunday)
    const dayOfWeek = today.getDay();
    const daysSinceMonday = dayOfWeek === 0 ? 7 : dayOfWeek; // Sunday = 7 days since Monday
    
    // Calculate weekly total (max 7 days)
    const weeklyTotal = Math.min(metersPerDay * daysSinceMonday, mDrld);
    
    return Math.round(weeklyTotal);
  }, []);

  // Memoized expensive computations
  const wells = useMemo(() => Array.from(new Set(operations.map(op => op.WellName))), [operations]);
  
  const selectedOp = useMemo(() => {
    const op = operations.find(op => op.WellName === selectedWell);
    console.log('Selected operation:', op);
    console.log('Selected operation WellID:', op?.WellID);
    return op;
  }, [operations, selectedWell]);
  
  // Memoized wells by province
  const wellsByProvince = useMemo(() => {
    return operations.reduce((acc, op) => {
      const province = getProvinceFromBlock(op.BlockName);
      if (!acc[province]) acc[province] = [];
      acc[province].push(op);
      return acc;
    }, {});
  }, [operations, getProvinceFromBlock]);

  // Memoized chart data
  const pieChartData = useMemo(() => {
    if (!selectedOp) return [];
    return [
      { name: 'Actual Depth', value: selectedOp.PresentDepthM },
      { name: 'Target Depth Remaining', value: Math.max(selectedOp.TDM - selectedOp.PresentDepthM, 0) }
    ];
  }, [selectedOp]);

  const barChartData = useMemo(() => {
    if (!selectedOp) return [];
    return [
      { name: selectedOp.WellName, Planned: selectedOp.DrlgDays, Actual: selectedOp.DryDays }
    ];
  }, [selectedOp]);

  const testBarChartData = useMemo(() => {
    if (!selectedOp) return [];
    return [
      { name: selectedOp.WellName, 'Dry Plan': selectedOp.TestDays, 'Actual Test': selectedOp.TestWODays }
    ];
  }, [selectedOp]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch("http://localhost:5000/drilling-operations");
        if (!res.ok) throw new Error("Failed to fetch data");
        const data = await res.json();
        console.log('Drilling operations data:', data);
        console.log('Sample operation WellID:', data[0]?.WellID);
        setOperations(data);
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };
    
    fetchData();
  }, [saving]);

  // Add GeneralNotes to editData when entering edit mode
  const handleEdit = useCallback(() => {
    setEditData({
      ...selectedOp,
      GeneralNotes: selectedOp.GeneralNotes || '',
      DrlgDays: selectedOp.DrlgDays || '',
      DryDays: selectedOp.DryDays || '',
      TestDays: selectedOp.TestDays || '',
      TestWODays: selectedOp.TestWODays || '',
      // Ensure fiscalYearPlans is initialized for editing
      fiscalYearPlans: selectedOp.fiscalYearPlans && selectedOp.fiscalYearPlans.length > 0
        ? [...selectedOp.fiscalYearPlans]
        : (selectedOp.FiscalYearPlans && selectedOp.FiscalYearPlans.length > 0
            ? [...selectedOp.FiscalYearPlans]
            : [])
    });
    setEditMode(true);
    setSaveError(null);
  }, [selectedOp]);

  const handleChange = useCallback((e) => {
    setEditData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  }, []);

  const handleCancel = useCallback(() => {
    setEditMode(false);
    setEditData({});
    setSaveError(null);
  }, []);

  // Add GeneralNotes to the save payload
  const handleSave = useCallback(async () => {
    setSaving(true);
    setSaveError(null);
    // Sanitize INT fields to avoid sending empty strings or undefined
    const sanitizeInt = val => (val === "" || val === null || val === undefined ? null : Number(val));
    const payload = {
      SrNo: sanitizeInt(editData.SrNo),
      SpudDate: editData.SpudDate || null,
      PresentDepthM: sanitizeInt(editData.PresentDepthM),
      TDM: sanitizeInt(editData.TDM),
      MDrld: editData.MDrld || null,
      OperationLog: editData.OperationLog || null,
      StopCard: sanitizeInt(editData.StopCard),
      GeneralNotes: editData.GeneralNotes || null,
      DrlgDays: sanitizeInt(editData.DrlgDays),
      DryDays: sanitizeInt(editData.DryDays),
      TestDays: sanitizeInt(editData.TestDays),
      TestWODays: sanitizeInt(editData.TestWODays)
    };
    try {
      const res = await fetch(`http://localhost:5000/drilling-operations/${selectedOp.DrillingOperationID}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error("Failed to save changes");
      setEditMode(false);
      setEditData({});
      setSaving(false);
      setSelectedWell(""); // Go back to all wells view
      setSelectedProvince("");
    } catch (err) {
      setSaveError(err.message);
      setSaving(false);
    }
  }, [selectedOp, editData]);

  const handleWellSelect = useCallback((wellName) => {
    setSelectedWell(wellName);
    setEditMode(false);
    setEditData({});
    if (wellName) {
      const selectedOperation = operations.find(op => op.WellName === wellName);
      if (selectedOperation) {
        setSelectedProvince(getProvinceFromBlock(selectedOperation.BlockName));
      }
    } else {
      setSelectedProvince("");
    }
  }, [operations, getProvinceFromBlock]);

  // Fetch history for a selected operation
  const fetchHistory = useCallback(async (drillingOperationId) => {
    try {
      const res = await fetch(`http://localhost:5000/drilling-operations/${drillingOperationId}/history`);
      if (!res.ok) throw new Error("Failed to fetch history");
      const data = await res.json();
      setHistory(data);
      setShowHistory(true);
    } catch (err) {
      setHistory([]);
      setShowHistory(true);
    }
  }, []);

  function getCurrentDateTimeString() {
    const now = new Date();
    const pad = n => n.toString().padStart(2, '0');
    return `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}_${pad(now.getHours())}-${pad(now.getMinutes())}`;
  }

  function getFyQuarterData(fyPlans, quarter) {
    if (!Array.isArray(fyPlans)) return '';
    const plan = fyPlans.find(p => (p.quarter || p.qtr || p.QTR || '').toString().includes(quarter));
    if (!plan) return '';
    // Try to show well name and meters if available
    return `${plan.well || plan.name || plan.detail || plan.plan || plan.details || ''}${plan.meters ? ' ('+plan.meters+' M)' : ''}`;
  }

  // Helper to extract all plans for a given quarter as a formatted string
  function getAllFyQuarterData(fyPlans, quarter) {
    if (!Array.isArray(fyPlans)) return '';
    const plans = fyPlans.filter(p => {
      const q = (p.quarter || p.qtr || p.QTR || '').toString();
      return q.includes(quarter);
    });
    if (!plans.length) return '';
    // Format: WellDepth (bold if possible), PlanDetails (italic if possible), each plan on a new line
    return plans.map(plan => {
      let line = '';
      if (plan.WellDepth) line += plan.WellDepth; // PDF can't do per-line bold, so just plain text
      if (plan.PlanDetails) line += (line ? '\n' : '') + plan.PlanDetails; // PDF can't do per-line italic, so just plain text
      return line;
    }).join('\n');
  }

  function buildTableRows(operations) {
    return operations.map((op, idx) => {
      const fyPlans = op.fiscalYearPlans || op.FiscalYearPlans || [];
      return [
        idx + 1,
        op.RigNo || '',
        `${op.WellName || ''}\n${op.BlockName || ''}${op.SpudDate ? '\n(' + op.SpudDate.split('T')[0] + ')' : ''}`,
        op.PresentDepthM ? `${op.PresentDepthM} m${op.PresentDepthFt ? ' ('+op.PresentDepthFt+' ft)' : ''}` : '',
        `${op.DrlgDays || ''}\n${op.TestDays || ''}`,
        `${op.DryDays || ''}\n${op.TestWODays || ''}`,
        op.TDM || '',
        op.OperationLog || '',
        getFyQuarterData(fyPlans, '1'),
        getFyQuarterData(fyPlans, '2'),
        getFyQuarterData(fyPlans, '3'),
        getFyQuarterData(fyPlans, '4')
      ];
    });
  }

  function getTableColumns() {
    return [
      { title: 'Sr. #', dataKey: 'sr' },
      { title: 'Rig #', dataKey: 'rig' },
      { title: 'Well', dataKey: 'well' },
      { title: 'Present Depth (TD)', dataKey: 'depth' },
      { title: 'Planned Rig AFE Days\nDrig | Test', dataKey: 'planned' },
      { title: 'Actual Rig Days\nDry | Test/WO', dataKey: 'actual' },
      { title: 'Mtr Drld', dataKey: 'mtr' },
      { title: 'Operations During Last 24 Hrs', dataKey: 'ops' },
      { title: 'F.Y 2025-26\n1st QTR', dataKey: 'fy1' },
      { title: '2nd QTR', dataKey: 'fy2' },
      { title: '3rd QTR', dataKey: 'fy3' },
      { title: '4th QTR', dataKey: 'fy4' }
    ];
  }

  // Helper to extract shares info from OperationLog
  function extractShares(operationLog) {
    if (!operationLog) return '';
    // Look for a line with company shares (e.g., OGDCL 65%, ...)
    const match = operationLog.match(/([A-Z]+\s*\d+%[\s,]*)+/);
    return match ? match[0].trim() : '';
  }

  // PDF Download Handler
  const handleDownloadPDF = async () => {
    // Fetch all fiscal year plans for the year
    let fyPlansAll = [];
    try {
      const fyRes = await fetch('http://localhost:5000/fiscal-year-plans-all?fy=2025-26');
      if (fyRes.ok) {
        fyPlansAll = await fyRes.json();
      }
    } catch (e) {
      // fallback: leave fyPlansAll empty
    }
    const doc = new jsPDF({ orientation: 'landscape' });
    const dateStr = getCurrentDateTimeString();
    const title = `ORM DRILLING OPERATIONS ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase()}`;
    doc.setFontSize(16);
    doc.setFont('helvetica', 'bold');
    doc.text(title, 14, 14);
    // Two-row header as in the screenshot
    const head = [
      [
        'Sr. #', 'Rig #', 'Well\nSpud date\nConcession\nState', 'Present Depth (TD) M',
        { content: 'Planned Rig AFE Days', colSpan: 2, styles: { halign: 'center', fillColor: [180, 198, 231] } },
        'Mtr Drld',
        { content: 'Actual Rig Days', colSpan: 2, styles: { halign: 'center', fillColor: [180, 198, 231] } },
        'Operations During Last 24 Hrs',
        'Stop Cards',
        { content: 'F.Y 2025-26', colSpan: 4, styles: { halign: 'center', fillColor: [255, 224, 178] } }
      ],
      [
        '', '', '', '', 'Drlg.', 'Test.', '', 'Dry', 'Test/WO', '', '', '1st QTR', '2nd QTR', '3rd QTR', '4th QTR'
      ]
    ];
    // Build rows
    const rows = [];
    operations.forEach((op, idx) => {
      // Find all plans for this well
      const wellPlans = fyPlansAll.filter(plan => plan.WellID === op.WellID);
      const getQ = q =>
        wellPlans
          .filter(plan => (plan.QTR || '').toLowerCase().includes(q.toLowerCase()))
          .map(plan => plan.WellName)
          .join(', ');
      // Extract shares info
      const shares = extractShares(op.OperationLog);
      let operationLogCell = (op.OperationLog || '').split('\n').map((line, i) => i === 0 ? `**${line}**` : line).join('\n');
      let sharesLines = [];
      if (shares) {
        sharesLines = shares.split(',').map(s => s.trim()).filter(Boolean);
        operationLogCell += '\n\n' + sharesLines.join('\n');
      }
      const mainRow = [
        idx + 1,
        op.RigNo || '',
        `${op.WellName || ''}\n${op.BlockName || ''}${op.SpudDate ? '\n(' + op.SpudDate.split('T')[0] + ')' : ''}`,
        op.PresentDepthM ? `${op.PresentDepthM}m${op.PresentDepthFt ? ' ('+op.PresentDepthFt+'ft)' : ''}` : '',
        op.DrlgDays || '',
        op.TestDays || '',
        { content: op.TDM || '', styles: { fontStyle: 'bold' } },
        op.DryDays || '',
        op.TestWODays || '',
        operationLogCell,
        op.StopCard || '',
        getQ('1st QTR'), getQ('2nd QTR'), getQ('3rd QTR'), getQ('4th QTR')
      ];
      rows.push(mainRow);
      // No shares row
    });
    autoTable(doc, {
      head: head,
      body: rows,
      startY: 22,
      styles: { fontSize: 8, cellPadding: 2, valign: 'middle', lineColor: [44,62,80], lineWidth: 0.2 },
      headStyles: { fillColor: [135, 206, 235], textColor: 44, fontStyle: 'bold', halign: 'center' },
      columnStyles: {
        1: { fontStyle: 'bold' },
        6: { fontStyle: 'bold' },
        11: { fillColor: [255, 236, 179] },
        12: { fillColor: [255, 236, 179] },
        13: { fillColor: [255, 236, 179] },
        14: { fillColor: [255, 236, 179] }
      },
      didParseCell: function (data) {
        // Italicize only shares lines in Operations During Last 24 Hrs
        if (data.section === 'body' && data.column.index === 9 && data.cell.raw) {
          const lines = data.cell.raw.split('\n');
          // Bold the first line
          if (lines.length > 0) {
            data.cell.styles.fontStyle = 'bold';
          }
          // If the current line is a shares line, italicize it
          if (lines.some(line => /^[A-Z ]+\s*\d+%$/.test(line.trim()))) {
            // This will apply italic to the whole cell if any line matches, but jsPDF-AutoTable does not support per-line style in a cell.
            // So, as a workaround, we can only apply italic to the cell if it contains only shares lines (not ideal, but a limitation of the library).
            // The main effect is that the shares lines will be visually separated as requested.
          }
        }
      }
    });
    doc.save(`DrillingOperations_${dateStr}.pdf`);
  };

  // Email PDF Handler
  const handleSendEmail = async () => {
    setEmailStatus('');
    setEmailLoading(true);
    try {
      // Fetch all fiscal year plans for the year (same as handleDownloadPDF)
      let fyPlansAll = [];
      try {
        const fyRes = await fetch('http://localhost:5000/fiscal-year-plans-all?fy=2025-26');
        if (fyRes.ok) {
          fyPlansAll = await fyRes.json();
        }
      } catch (e) {
        // fallback: leave fyPlansAll empty
      }
      const doc = new jsPDF({ orientation: 'landscape' });
      const dateStr = getCurrentDateTimeString();
      const title = `ORM DRILLING OPERATIONS ${new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }).toUpperCase()}`;
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text(title, 14, 14);
      const head = [
        [
          'Sr. #', 'Rig #', 'Well\nSpud date\nConcession\nState', 'Present Depth (TD) M',
          { content: 'Planned Rig AFE Days', colSpan: 2, styles: { halign: 'center', fillColor: [180, 198, 231] } },
          'Mtr Drld',
          { content: 'Actual Rig Days', colSpan: 2, styles: { halign: 'center', fillColor: [180, 198, 231] } },
          'Operations During Last 24 Hrs',
          'Stop Cards',
          { content: 'F.Y 2025-26', colSpan: 4, styles: { halign: 'center', fillColor: [255, 224, 178] } }
        ],
        [
          '', '', '', '', 'Drlg.', 'Test.', '', 'Dry', 'Test/WO', '', '', '1st QTR', '2nd QTR', '3rd QTR', '4th QTR'
        ]
      ];
      const rows = [];
      operations.forEach((op, idx) => {
        // Find all plans for this well (same as handleDownloadPDF)
        const wellPlans = fyPlansAll.filter(plan => plan.WellID === op.WellID);
        const getQ = q =>
          wellPlans
            .filter(plan => (plan.QTR || '').toLowerCase().includes(q.toLowerCase()))
            .map(plan => plan.WellName)
            .join(', ');
        // Extract shares info
        const shares = extractShares(op.OperationLog);
        let operationLogCell = (op.OperationLog || '').split('\n').map((line, i) => i === 0 ? `**${line}**` : line).join('\n');
        let sharesLines = [];
        if (shares) {
          sharesLines = shares.split(',').map(s => s.trim()).filter(Boolean);
          operationLogCell += '\n\n' + sharesLines.join('\n');
        }
        const mainRow = [
          idx + 1,
          op.RigNo || '',
          `${op.WellName || ''}\n${op.BlockName || ''}${op.SpudDate ? '\n(' + op.SpudDate.split('T')[0] + ')' : ''}`,
          op.PresentDepthM ? `${op.PresentDepthM}m${op.PresentDepthFt ? ' ('+op.PresentDepthFt+'ft)' : ''}` : '',
          op.DrlgDays || '',
          op.TestDays || '',
          { content: op.TDM || '', styles: { fontStyle: 'bold' } },
          op.DryDays || '',
          op.TestWODays || '',
          operationLogCell,
          op.StopCard || '',
          getQ('1st QTR'), getQ('2nd QTR'), getQ('3rd QTR'), getQ('4th QTR')
        ];
        rows.push(mainRow);
      });
      autoTable(doc, {
        head: head,
        body: rows,
        startY: 22,
        styles: { fontSize: 8, cellPadding: 2, valign: 'middle', lineColor: [44,62,80], lineWidth: 0.2 },
        headStyles: { fillColor: [44, 62, 80], textColor: 255, fontStyle: 'bold', halign: 'center' },
        columnStyles: {
          1: { fontStyle: 'bold' },
          6: { fontStyle: 'bold' },
          11: { fillColor: [255, 236, 179] },
          12: { fillColor: [255, 236, 179] },
          13: { fillColor: [255, 236, 179] },
          14: { fillColor: [255, 236, 179] }
        },
        didParseCell: function (data) {
          if (data.section === 'body' && data.column.index === 9 && data.cell.raw) {
            const lines = data.cell.raw.split('\n');
            if (lines.length > 0) {
              data.cell.styles.fontStyle = 'bold';
            }
          }
        }
      });
      const pdfBlob = doc.output('blob');
      const formData = new FormData();
      formData.append('pdf', pdfBlob, `DrillingOperations_${dateStr}.pdf`);
      formData.append('to', 'zakinabeelalu@gmail.com');
      formData.append('subject', 'Drilling Operations Report');
      formData.append('body', 'Please find attached the latest drilling operations report.');
      const response = await fetch('http://localhost:5000/send-drilling-report', {
        method: 'POST',
        body: formData
      });
      if (response.ok) {
        setEmailStatus('Email sent successfully!');
      } else {
        setEmailStatus('Failed to send email.');
      }
    } catch (err) {
      setEmailStatus('Error sending email.');
    } finally {
      setEmailLoading(false);
    }
  };

  // Add New Well handler
  const handleAddNewWell = async (formData) => {
    try {
      const payload = { ...formData };
      // Convert numeric fields
      payload.Longitude = payload.Longitude ? Number(payload.Longitude) : null;
      payload.Latitude = payload.Latitude ? Number(payload.Latitude) : null;
      payload.TargetDepth = payload.TargetDepth ? Number(payload.TargetDepth) : null;
      payload.PlannedAFEDaysDrilling = payload.PlannedAFEDaysDrilling ? Number(payload.PlannedAFEDaysDrilling) : null;
      payload.PlannedAFEDaysActual = payload.PlannedAFEDaysActual ? Number(payload.PlannedAFEDaysActual) : null;
      
      const res = await fetch('http://localhost:5000/drilling-operations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!res.ok) throw new Error('Failed to add new well');
      setSaving(s => !s); // trigger refresh
    } catch (err) {
      throw new Error(err.message);
    }
  };

  // Delete Well handler
  const handleDeleteWell = async (drillingOperationId) => {
    if (!window.confirm('Are you sure you want to delete this well?')) return;
    setDeletingWellId(drillingOperationId);
    try {
      const res = await fetch(`http://localhost:5000/drilling-operations/${drillingOperationId}`, {
        method: 'DELETE'
      });
      if (!res.ok) throw new Error('Failed to delete well');
      setDeletingWellId(null);
      setSelectedWell("");
      setSaving(s => !s); // trigger refresh
    } catch (err) {
      setDeletingWellId(null);
      alert('Error deleting well: ' + err.message);
    }
  };

  const handleFetchPastWells = async () => {
    setPastWellsLoading(true);
    try {
      const res = await fetch('http://localhost:5000/past-wells');
      if (!res.ok) throw new Error('Failed to fetch past wells');
      const data = await res.json();
      setPastWells(data);
      setShowPastWellsModal(true);
    } catch (err) {
      alert('Error fetching past wells: ' + err.message);
    } finally {
      setPastWellsLoading(false);
    }
  };

  if (loading) return (
    <div style={{ textAlign: 'center', padding: '40px' }}>
      <div className="loading-spinner"></div>
      <div style={{ marginTop: '16px', color: 'white', fontSize: '18px' }}>Loading drilling operations...</div>
    </div>
  );
  
  if (error) return <div style={{color: '#ff6b6b', textAlign: 'center', padding: '20px', background: 'rgba(255,107,107,0.1)', borderRadius: '8px'}}>Error: {error}</div>;

  return (
    <div style={{ padding: '24px', maxWidth: '1400px', margin: '0 auto', background: 'linear-gradient(135deg, #23234c 0%, #2b5876 100%)', borderRadius: 18, boxShadow: '0 8px 32px rgba(25, 118, 210, 0.10)' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div style={{ display: 'flex', gap: 12 }}>
          <button
            onClick={() => setShowAddModal(true)}
            style={{ background: '#388e3c', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 24px', fontWeight: 700, fontSize: 16, cursor: 'pointer', boxShadow: '0 2px 8px rgba(56, 142, 60, 0.10)' }}
          >
            + Add New Well
          </button>
          <button
            onClick={() => setShowDeleteModal(true)}
            style={{ background: '#d32f2f', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 24px', fontWeight: 700, fontSize: 16, cursor: 'pointer', boxShadow: '0 2px 8px rgba(211, 47, 47, 0.10)' }}
          >
            Delete Well(s)
          </button>
          <button
            onClick={handleFetchPastWells}
            disabled={pastWellsLoading}
            style={{ 
              background: pastWellsLoading ? '#ccc' : '#ff9800', 
              color: '#fff', 
              border: 'none', 
              borderRadius: 8, 
              padding: '10px 24px', 
              fontWeight: 700, 
              fontSize: 16, 
              cursor: pastWellsLoading ? 'not-allowed' : 'pointer', 
              boxShadow: '0 2px 8px rgba(255, 152, 0, 0.10)' 
            }}
          >
            {pastWellsLoading ? 'Loading...' : 'Past Wells'}
          </button>
        </div>
        <div style={{ display: 'flex', gap: 16 }}>
          <button
            onClick={() => navigate('/slideshow')}
            style={{
              background: '#6a1b9a',
              color: '#fff',
              border: 'none',
              borderRadius: 8,
              padding: '10px 24px',
              fontWeight: 700,
              fontSize: 16,
              cursor: 'pointer',
              boxShadow: '0 2px 8px rgba(106,27,154,0.10)'
            }}
          >
            View All Wells Slideshow
          </button>
          <button onClick={handleDownloadPDF} style={{ background: '#1976d2', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 24px', fontWeight: 700, fontSize: 16, cursor: 'pointer', boxShadow: '0 2px 8px rgba(25, 118, 210, 0.10)' }}>
            Download PDF
          </button>
          <button onClick={handleSendEmail} disabled={emailLoading} style={{ background: '#388e3c', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 24px', fontWeight: 700, fontSize: 16, cursor: emailLoading ? 'not-allowed' : 'pointer', boxShadow: '0 2px 8px rgba(56, 142, 60, 0.10)' }}>
            {emailLoading ? 'Sending...' : 'Send Email to Manager'}
          </button>
        </div>
      </div>
      {emailStatus && (
        <div style={{ textAlign: 'right', color: emailStatus.includes('success') ? '#43ea7f' : '#ff5252', fontWeight: 600, marginBottom: 8 }}>
          {emailStatus}
        </div>
      )}
      <WellSelector wells={wells} selectedWell={selectedWell} onSelect={handleWellSelect} />

      {/* Show all wells with status if no well is selected */}
      {!selectedWell && operations.length > 0 && (
        <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 32, marginTop: 32, justifyContent: 'center' }}>
            {operations.map(op => (
              <div key={op.WellName} style={{ position: 'relative' }}>
                <WellSummaryCard op={op} onSelect={handleWellSelect} />
              </div>
            ))}
          </div>
          {/* Carousel of Pie Charts for all wells */}
          <div style={{ margin: '48px 0 0 0', width: '100%', textAlign: 'center' }}>
            <Slider
              dots={false}
              infinite={true}
              speed={500}
              slidesToShow={3}
              slidesToScroll={1}
              autoplay={true}
              autoplaySpeed={2000}
              arrows={false}
              pauseOnHover={true}
              responsive={[
                { breakpoint: 1200, settings: { slidesToShow: 2 } },
                { breakpoint: 800, settings: { slidesToShow: 1 } }
              ]}
            >
              {operations.map((well) => (
                <div key={well.DrillingOperationID} style={{ textAlign: 'center' }}>
                  <WellPieChartBox well={well} />
                </div>
              ))}
            </Slider>
          </div>

          {/* General Notes Box - Main Dashboard */}
          <div style={{ 
            marginTop: 48, 
            padding: 24, 
            background: '#23234c', 
            borderRadius: 12, 
            border: 'none',
            color: '#fff',
            boxShadow: '0 4px 16px rgba(25, 118, 210, 0.10)',
            fontFamily: 'Inter, Segoe UI, Arial, sans-serif',
            textAlign: 'center',
            maxWidth: '1200px',
            margin: '48px auto 0 auto'
          }}>
            <h4 style={{ margin: '0 0 16px 0', color: '#fff', background: 'transparent', padding: 0, borderRadius: 0, fontSize: '20px', fontWeight: 700, letterSpacing: 0.5, textAlign: 'center' }}>General Notes</h4>
            <div style={{ fontSize: 18, lineHeight: 1.8, color: '#fff', background: 'transparent', padding: 0, borderRadius: 0, fontFamily: 'Inter, Segoe UI, Arial, sans-serif', textAlign: 'center' }}>
              <div style={{ marginBottom: '8px', textAlign: 'center' }}>Target: 2025-26: 16 Wells (Spudded: 4, Exp: 3, Dev: 0, S/T/R/E: 00, W/O: 8, P&A: 1)</div>
              <div style={{ marginBottom: '8px', textAlign: 'center' }}>Meter Drilled in F.Y 2025-26: Since July 01, 2024 = 21753 M, In march, 2025 = 1906 M.</div>
              <div style={{ textAlign: 'center' }}>Note:- Rig N-1 stacked at location# Rajian-7 & under technical assessment</div>
            </div>
          </div>
        </>
      )}

      {/* Province Image and Well Location Map Side by Side */}
      {selectedOp && (
        <div style={{ display: 'flex', gap: 32, marginBottom: 24, justifyContent: 'center', alignItems: 'center' }}>
          <ProvinceImage province={selectedProvince} />
          <WellMap latitude={selectedOp.Latitude} longitude={selectedOp.Longitude} wellName={selectedOp.WellName} blockName={selectedOp.BlockName} />
        </div>
      )}

      {selectedOp && (
        <div className="professional-card" style={{ padding: 24, marginBottom: 32, position: 'relative', maxWidth: '1200px', margin: '0 auto 32px auto', background: 'linear-gradient(135deg, #e0eafc 0%, #fffde4 100%)', borderRadius: 16, boxShadow: '0 8px 32px rgba(25, 118, 210, 0.10)' }}>
          {/* Back Button */}
          <div style={{ marginBottom: 16, textAlign: 'center' }}>
            <button
              onClick={() => handleWellSelect("")}
              style={{
                background: '#23234c',
                color: '#fff',
                border: '2px solid #90caf9',
                borderRadius: 8,
                padding: '8px 20px',
                fontWeight: 600,
                fontSize: 16,
                cursor: 'pointer',
                marginBottom: 8,
                transition: 'background 0.2s, color 0.2s',
              }}
            >
              ← Back to All Wells
            </button>
          </div>

          {/* Header Section with Logo and Well Info */}
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', marginBottom: 24, flexDirection: 'column', textAlign: 'center' }}>
            {/* Company Logo */}
            <div style={{ 
              width: 120, 
              height: 120, 
              borderRadius: '50%', 
              background: 'linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%)',
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'center',
              boxShadow: '0 8px 24px rgba(25, 118, 210, 0.3)',
              overflow: 'hidden',
              marginBottom: 24
            }}>
              <img 
                src="/OGDCL_logo.svg-removebg-preview.png" 
                alt="Company Logo" 
                style={{ width: '100%', height: '100%', objectFit: 'contain', padding: '8px' }}
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.nextSibling.style.display = 'flex';
                }}
              />
              <div style={{ 
                display: 'none', 
                flexDirection: 'column', 
                alignItems: 'center', 
                justifyContent: 'center',
                color: '#1976d2',
                fontSize: 10,
                textAlign: 'center',
                fontWeight: 'bold',
                padding: '8px'
              }}>
                GAS DEVELOPMENT<br />COMPANY LIMITED<br />OIL & GAS
              </div>
            </div>

            {/* Well Identification */}
            <div style={{ width: '100%', textAlign: 'center' }}>
              <div style={{ display: 'flex', gap: 16, marginBottom: 16, justifyContent: 'center', flexWrap: 'wrap' }}>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <span style={{ fontWeight: 'bold', marginRight: 8, fontSize: '16px' }}>RIG:</span>
                  <span style={{ padding: '6px 14px', background: '#f5f5f5', borderRadius: 4, border: '1px solid #ddd', fontSize: '16px', fontWeight: '500' }}>
                    {selectedOp.RigNo}
                  </span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <span style={{ fontWeight: 'bold', marginRight: 8, color: '#d32f2f', fontSize: '16px' }}>WELL:</span>
                  <span style={{ padding: '6px 14px', background: '#ffebee', borderRadius: 4, border: '1px solid #ffcdd2', color: '#d32f2f', fontSize: '16px', fontWeight: '500' }}>
                    {selectedOp.WellName}
                  </span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center' }}>
                  <span style={{ fontWeight: 'bold', marginRight: 8, fontSize: '16px' }}>BLOCK:</span>
                  <span style={{ padding: '6px 14px', background: '#f5f5f5', borderRadius: 4, border: '1px solid #ddd', fontSize: '16px', fontWeight: '500' }}>
                    {selectedOp.BlockName}
                  </span>
                </div>
              </div>

              {/* Drilling Progress Data - Modern Grouped Style */}
              <div style={{ display: 'flex', gap: 20, marginBottom: 24, justifyContent: 'center', flexWrap: 'wrap' }}>
                {/* Spud Date */}
                <div style={{ flex: 1, background: '#23234c', color: 'white', borderRadius: 12, padding: '24px 20px', minWidth: 200, minHeight: 120, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  {editMode ? (
                    <>
                      <div style={{ fontSize: 24, fontWeight: 500, lineHeight: 1, textAlign: 'center' }}>
                        {selectedOp.SpudDate ? selectedOp.SpudDate.split('T')[0] : '00-Jan-00'}
                      </div>
                      <div style={{ fontSize: 24, fontWeight: 800, marginTop: 6, textAlign: 'center' }}>Spud Date</div>
                    </>
                  ) : (
                    <>
                      <div style={{ fontSize: 24, fontWeight: 500, lineHeight: 1, textAlign: 'center' }}>{selectedOp.SpudDate ? selectedOp.SpudDate.split('T')[0] : '00-Jan-00'}</div>
                      <div style={{ fontSize: 24, fontWeight: 800, marginTop: 6, textAlign: 'center' }}>Spud Date</div>
                    </>
                  )}
                </div>
                {/* Present Depth M & Target Depth M Grouped */}
                <div style={{ flex: 1.2, background: '#23234c', color: 'white', borderRadius: 12, padding: '24px 20px', minWidth: 300, minHeight: 120, display: 'flex', flexDirection: 'row', gap: 24, justifyContent: 'space-between', alignItems: 'center' }}>
                  <div style={{ flex: 1, textAlign: 'center' }}>
                    {editMode ? (
                      <>
                        <input
                          type="number"
                          name="PresentDepthM"
                          value={editData.PresentDepthM}
                          onChange={handleChange}
                          style={{ fontSize: 24, fontWeight: 500, background: '#23234c', color: 'white', border: '1px solid #444', borderRadius: 6, padding: 8, textAlign: 'center', width: '100%' }}
                        />
                        <div style={{ fontSize: 24, fontWeight: 800, marginTop: 6, textAlign: 'center' }}>Present Depth M</div>
                      </>
                    ) : (
                      <>
                        <div style={{ fontSize: 24, fontWeight: 700, lineHeight: 1, textAlign: 'center' }}>{selectedOp.PresentDepthM}</div>
                        <div style={{ fontSize: 24, fontWeight: 800, marginTop: 6, textAlign: 'center' }}>Present Depth M</div>
                      </>
                    )}
                  </div>
                  <div style={{ width: 2, background: 'rgba(255,255,255,0.08)', height: 48, borderRadius: 1 }}></div>
                  <div style={{ flex: 1, textAlign: 'center' }}>
                    {editMode ? (
                      <>
                        <input
                          type="number"
                          name="TDM"
                          value={editData.TDM}
                          onChange={handleChange}
                          style={{ fontSize: 24, fontWeight: 500, background: '#23234c', color: 'white', border: '1px solid #444', borderRadius: 6, padding: 8, textAlign: 'center', width: '100%' }}
                        />
                        <div style={{ fontSize: 24, fontWeight: 800, marginTop: 6, textAlign: 'center' }}>Target Depth M</div>
                      </>
                    ) : (
                      <>
                        <div style={{ fontSize: 24, fontWeight: 700, lineHeight: 1, textAlign: 'center' }}>{selectedOp.TDM}</div>
                        <div style={{ fontSize: 24, fontWeight: 800, marginTop: 6, textAlign: 'center' }}>Target Depth M</div>
                      </>
                    )}
                  </div>
                </div>
                {/* Meters Drilled */}
                <div style={{ flex: 1, background: '#23234c', color: 'white', borderRadius: 12, padding: '24px 20px', minWidth: 200, minHeight: 120, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  {editMode ? (
                    <>
                      <input
                        type="number"
                        name="MDrld"
                        value={editData.MDrld || ''}
                        onChange={handleChange}
                        style={{ fontSize: 24, fontWeight: 500, background: '#23234c', color: 'white', border: '1px solid #444', borderRadius: 6, padding: 8, textAlign: 'center', width: '100%' }}
                      />
                      <div style={{ fontSize: 24, fontWeight: 800, marginTop: 6, textAlign: 'center' }}>Meters Drilled</div>
                    </>
                  ) : (
                    <>
                      <div style={{ fontSize: 24, fontWeight: 700, lineHeight: 1, textAlign: 'center' }}>{selectedOp.MDrld}</div>
                      <div style={{ fontSize: 24, fontWeight: 800, marginTop: 6, textAlign: 'center' }}>Meters Drilled</div>
                    </>
                  )}
                </div>
                {/* Weekly */}
                <div style={{ flex: 1, background: '#23234c', color: 'white', borderRadius: 12, padding: '24px 20px', minWidth: 200, minHeight: 120, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
                  <div style={{ fontSize: 24, fontWeight: 700, lineHeight: 1, textAlign: 'center' }}>
                    {calculateWeeklyMetersDrilled(selectedOp.MDrld, selectedOp.LastUpdated)}
                  </div>
                  <div style={{ fontSize: 24, fontWeight: 800, marginTop: 6, textAlign: 'center' }}>Weekly</div>
                </div>
              </div>
            </div>
          </div>

          {/* Planned vs Actual Days Section */}
          <div style={{ display: 'flex', gap: 24, marginBottom: 24, justifyContent: 'center', flexWrap: 'wrap' }}>
            {/* Drilling Planned vs Actual Days */}
            <div style={{ flex: 1, background: '#23234c', color: '#fff', borderRadius: 12, padding: 20, minHeight: '140px', boxShadow: '0 4px 16px rgba(25, 118, 210, 0.10)', border: 'none', fontFamily: 'Inter, Segoe UI, Arial, sans-serif', minWidth: 300, textAlign: 'center' }}>
              <h4 style={{ margin: '0 0 16px 0', color: '#fff', background: 'transparent', padding: 0, borderRadius: 0, fontSize: '22px', fontWeight: 800, letterSpacing: 0.5, textAlign: 'center' }}>Drilling Planned vs Actual Days</h4>
              <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
                <div style={{ flex: 1, background: '#28306e', borderRadius: 8, padding: 12, textAlign: 'center', border: 'none' }}>
                  <div style={{ fontWeight: 800, fontSize: '18px', marginBottom: '8px', color: '#fff' }}>Drlg Plan</div>
                  {editMode ? (
                    <input
                      type="number"
                      name="DrlgDays"
                      value={editData.DrlgDays}
                      onChange={handleChange}
                      style={{ fontSize: 20, color: '#fff', fontWeight: 500, background: '#28306e', border: '1px solid #444', borderRadius: 6, padding: 8, textAlign: 'center', width: '100%' }}
                    />
                  ) : (
                    <div style={{ fontSize: 20, color: '#fff', fontWeight: 700 }}>{selectedOp.DrlgDays}</div>
                  )}
                </div>
                <div style={{ flex: 1, background: '#2e1a2f', borderRadius: 8, padding: 12, textAlign: 'center', border: 'none' }}>
                  <div style={{ fontWeight: 800, fontSize: '18px', marginBottom: '8px', color: '#fff' }}>Actual</div>
                  {editMode ? (
                    <input
                      type="number"
                      name="DryDays"
                      value={editData.DryDays}
                      onChange={handleChange}
                      style={{ fontSize: 20, color: '#fff', fontWeight: 500, background: '#2e1a2f', border: '1px solid #444', borderRadius: 6, padding: 8, textAlign: 'center', width: '100%' }}
                    />
                  ) : (
                    <div style={{ fontSize: 20, color: '#fff', fontWeight: 700 }}>{selectedOp.DryDays || 0}</div>
                  )}
                </div>
              </div>
            </div>
            {/* Test/WO Test vs Actual */}
            <div style={{ flex: 1, background: '#23234c', color: '#fff', borderRadius: 12, padding: 20, minHeight: '140px', boxShadow: '0 4px 16px rgba(25, 118, 210, 0.10)', border: 'none', fontFamily: 'Inter, Segoe UI, Arial, sans-serif', minWidth: 300, textAlign: 'center' }}>
              <h4 style={{ margin: '0 0 16px 0', color: '#fff', background: 'transparent', padding: 0, borderRadius: 0, fontSize: '22px', fontWeight: 800, letterSpacing: 0.5, textAlign: 'center' }}>Test/WO Test vs Actual</h4>
              <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
                <div style={{ flex: 1, background: '#1b3c2e', borderRadius: 8, padding: 12, textAlign: 'center', border: 'none' }}>
                  <div style={{ fontWeight: 800, fontSize: '18px', marginBottom: '8px', color: '#fff' }}>Dry Plan</div>
                  {editMode ? (
                    <input
                      type="number"
                      name="TestDays"
                      value={editData.TestDays}
                      onChange={handleChange}
                      style={{ fontSize: 20, color: '#fff', fontWeight: 500, background: '#1b3c2e', border: '1px solid #444', borderRadius: 6, padding: 8, textAlign: 'center', width: '100%' }}
                    />
                  ) : (
                    <div style={{ fontSize: 20, color: '#fff', fontWeight: 700 }}>{selectedOp.TestDays}</div>
                  )}
                </div>
                <div style={{ flex: 1, background: '#4d3a1a', borderRadius: 8, padding: 12, textAlign: 'center', border: 'none' }}>
                  <div style={{ fontWeight: 800, fontSize: '18px', marginBottom: '8px', color: '#fff' }}>Actual Test</div>
                  {editMode ? (
                    <input
                      type="number"
                      name="TestWODays"
                      value={editData.TestWODays}
                      onChange={handleChange}
                      style={{ fontSize: 20, color: '#fff', fontWeight: 500, background: '#4d3a1a', border: '1px solid #444', borderRadius: 6, padding: 8, textAlign: 'center', width: '100%' }}
                    />
                  ) : (
                    <div style={{ fontSize: 20, color: '#fff', fontWeight: 700 }}>{selectedOp.TestWODays || 0}</div>
                  )}
                </div>
              </div>
            </div>
            {/* STOP CARDS */}
            <div style={{ background: '#23234c', color: '#fff', borderRadius: 12, padding: 20, minHeight: '140px', boxShadow: '0 4px 16px rgba(25, 118, 210, 0.10)', border: 'none', flex: 1, fontFamily: 'Inter, Segoe UI, Arial, sans-serif', minWidth: 300, textAlign: 'center' }}>
              <h4 style={{ margin: '0 0 16px 0', color: '#fff', background: 'transparent', padding: 0, borderRadius: 0, fontSize: '22px', fontWeight: 800, letterSpacing: 0.5, textAlign: 'center' }}>STOP CARDS</h4>
                                <div style={{ fontSize: 32, fontWeight: 700, color: '#fff', textAlign: 'center' }}>
                {editMode ? (
                  <input
                    type="text"
                    name="StopCard"
                    value={editData.StopCard}
                    onChange={handleChange}
                    style={{ fontSize: 20, fontWeight: 500, background: '#23234c', color: 'white', border: '1px solid #444', borderRadius: 6, padding: 8, textAlign: 'center', width: '100%' }}
                  />
                ) : (
                  selectedOp.StopCard
                )}
              </div>
            </div>
          </div>

          {/* Visualization Section (Frontend-only, using recharts) */}
          <div style={{ margin: '40px 0', display: 'flex', gap: 32, justifyContent: 'center', flexWrap: 'wrap' }}>
            <WellCharts
              pieChartData={pieChartData}
              barChartData={barChartData}
              testBarChartData={testBarChartData}
            />
          </div>

          {/* Status and Operation Log */}
          <div style={{ marginBottom: 24, marginTop: 24, textAlign: 'center' }}>
            <div style={{ 
              background: '#23234c', 
              color: '#fff', 
              padding: '10px 18px', 
              borderRadius: 8, 
              display: 'inline-block',
              fontWeight: 700,
              marginBottom: 16,
              fontSize: '20px',
              boxShadow: '0 4px 16px rgba(25, 118, 210, 0.10)',
              border: 'none',
              fontFamily: 'Inter, Segoe UI, Arial, sans-serif',
              textAlign: 'center'
            }}>
              {selectedOp.OperationLog ? selectedOp.OperationLog.split('.')[0] + '.' : (selectedOp.PlanDetails || 'No status available')}
            </div>
            <div style={{ 
              background: '#23234c', color: '#fff', borderRadius: 12, padding: 24, boxShadow: '0 4px 16px rgba(25, 118, 210, 0.10)', border: 'none', fontFamily: 'Inter, Segoe UI, Arial, sans-serif', textAlign: 'center' }}>
              <h4 style={{ margin: '0 0 16px 0', color: '#fff', background: 'transparent', padding: 0, borderRadius: 0, fontSize: '24px', fontWeight: 900, letterSpacing: 0.5, textAlign: 'center' }}>Operation Log</h4>
              <div style={{ 
                whiteSpace: 'pre-line', 
                lineHeight: 1.8, 
                color: '#fff',
                fontFamily: 'Inter, Segoe UI, Arial, sans-serif',
                fontSize: 22, // bigger
                background: 'transparent',
                padding: 0,
                borderRadius: 0,
                border: 'none',
                minHeight: '120px',
                textAlign: 'center'
              }}>
                {editMode ? (
                  <textarea
                    name="OperationLog"
                    value={editData.OperationLog}
                    onChange={handleChange}
                    style={{ width: '100%', height: '100%', background: 'transparent', border: '1px solid #444', borderRadius: 6, padding: 8, fontSize: 22, color: '#fff', fontFamily: 'Inter, Segoe UI, Arial, sans-serif', textAlign: 'center' }}
                  />
                ) : (
                  selectedOp.OperationLog
                )}
              </div>
            </div>
          </div>

          {/* Fiscal Year Planning */}
          <FiscalYearDisplay
            wellId={selectedOp.WellID}
            wellName={selectedOp.WellName}
            editMode={editMode}
            fiscalYearPlans={editData.fiscalYearPlans || []}
            onFiscalYearChange={plans => setEditData(prev => ({ ...prev, fiscalYearPlans: plans }))}
          />



          {/* Edit Button or Save/Cancel + View History Button */}
          <div style={{ marginTop: 24, textAlign: 'center' }}>
            {editMode ? (
              <>
                <button onClick={handleSave} className="professional-button" style={{ marginRight: 16 }}>Update</button>
                <button onClick={handleCancel} className="professional-button" style={{ background: '#ff8a80', color: '#23234c' }}>Cancel</button>
                {saveError && <div style={{ color: '#ff8a80', marginTop: 12, textAlign: 'center' }}>{saveError}</div>}
              </>
            ) : (
              <>
                <button onClick={handleEdit} className="professional-button">Edit Well Data</button>
                <button
                  onClick={() => navigate(`/history/${selectedOp.WellID}`)}
                  className="professional-button"
                  style={{ marginLeft: 16, background: '#1976d2', color: '#fff' }}
                >
                  View History
                </button>
              </>
            )}
          </div>
        </div>
      )}
      {/* Add New Well Modal */}
      {showAddModal && (
        <AddWellModal
          isOpen={showAddModal}
          onClose={() => setShowAddModal(false)}
          onSubmit={handleAddNewWell}
        />
      )}
      {/* Delete Well Modal */}
      {showDeleteModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.4)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ background: '#fff', padding: 32, borderRadius: 12, minWidth: 400, maxWidth: 600, boxShadow: '0 4px 32px rgba(25, 118, 210, 0.20)' }}>
            <h2 style={{ marginBottom: 16, color: '#d32f2f' }}>Delete Well(s)</h2>
            <div style={{ maxHeight: 300, overflowY: 'auto', marginBottom: 16 }}>
              {operations.length === 0 && <div>No wells found.</div>}
              {operations.map(op => (
                <label key={op.DrillingOperationID} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
                  <input
                    type="checkbox"
                    checked={selectedWellsToDelete.includes(op.DrillingOperationID)}
                    onChange={e => {
                      setSelectedWellsToDelete(prev =>
                        e.target.checked
                          ? [...prev, op.DrillingOperationID]
                          : prev.filter(id => id !== op.DrillingOperationID)
                      );
                    }}
                  />
                  <span style={{ fontWeight: 600 }}>{op.WellName}</span>
                  <span style={{ color: '#888', fontSize: 13 }}>({op.BlockName})</span>
                </label>
              ))}
            </div>
            {deleteError && <div style={{ color: 'red', marginBottom: 8 }}>{deleteError}</div>}
            <div style={{ display: 'flex', gap: 12, justifyContent: 'flex-end' }}>
              <button onClick={() => setShowDeleteModal(false)} style={{ background: '#eee', color: '#23234c', border: 'none', borderRadius: 6, padding: '8px 18px', fontWeight: 600 }}>Cancel</button>
              <button
                onClick={async () => {
                  setDeleteLoading(true);
                  setDeleteError(null);
                  try {
                    for (const id of selectedWellsToDelete) {
                      const res = await fetch(`http://localhost:5000/drilling-operations/${id}`, { method: 'DELETE' });
                      if (!res.ok) throw new Error('Failed to delete well');
                    }
                    setShowDeleteModal(false);
                    setSelectedWellsToDelete([]);
                    setSaving(s => !s); // refresh
                  } catch (err) {
                    setDeleteError(err.message);
                  } finally {
                    setDeleteLoading(false);
                  }
                }}
                disabled={deleteLoading || selectedWellsToDelete.length === 0}
                style={{ background: '#d32f2f', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 18px', fontWeight: 600, opacity: selectedWellsToDelete.length === 0 ? 0.6 : 1, cursor: selectedWellsToDelete.length === 0 ? 'not-allowed' : 'pointer' }}
              >
                {deleteLoading ? 'Deleting...' : 'Confirm Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Past Wells Modal */}
      {showPastWellsModal && (
        <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', background: 'rgba(0,0,0,0.4)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ background: '#fff', padding: 32, borderRadius: 12, minWidth: 800, maxWidth: '90vw', maxHeight: '90vh', boxShadow: '0 4px 32px rgba(25, 118, 210, 0.20)', overflow: 'auto' }}>
            <h2 style={{ marginBottom: 16, color: '#ff9800' }}>Past Wells (Deleted Wells)</h2>
            {pastWells.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '40px', color: '#666' }}>
                No past wells found. Deleted wells will appear here.
              </div>
            ) : (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px' }}>
                  <thead>
                    <tr style={{ background: '#f5f5f5' }}>
                      <th style={{ padding: '12px 8px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Well Name</th>
                      <th style={{ padding: '12px 8px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Rig</th>
                      <th style={{ padding: '12px 8px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Block</th>
                      <th style={{ padding: '12px 8px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Spud Date</th>
                      <th style={{ padding: '12px 8px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Present Depth</th>
                      <th style={{ padding: '12px 8px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Target Depth</th>
                      <th style={{ padding: '12px 8px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Operation Log</th>
                      <th style={{ padding: '12px 8px', textAlign: 'left', borderBottom: '2px solid #ddd' }}>Deleted At</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pastWells.map((well, index) => (
                      <tr key={well.PastWellID} style={{ borderBottom: '1px solid #eee', background: index % 2 === 0 ? '#fff' : '#fafafa' }}>
                        <td style={{ padding: '12px 8px' }}>{well.WellName}</td>
                        <td style={{ padding: '12px 8px' }}>{well.RigNo}</td>
                        <td style={{ padding: '12px 8px' }}>{well.BlockName}</td>
                        <td style={{ padding: '12px 8px' }}>{well.SpudDate ? new Date(well.SpudDate).toLocaleDateString() : '-'}</td>
                        <td style={{ padding: '12px 8px' }}>{well.PresentDepthM || '-'}</td>
                        <td style={{ padding: '12px 8px' }}>{well.TDM || '-'}</td>
                        <td style={{ padding: '12px 8px', maxWidth: '300px', wordWrap: 'break-word' }}>
                          {well.OperationLog ? (
                            <div style={{ 
                              maxHeight: '100px', 
                              overflow: 'auto', 
                              fontSize: '12px',
                              lineHeight: '1.4'
                            }}>
                              {well.OperationLog}
                            </div>
                          ) : '-'}
                        </td>
                        <td style={{ padding: '12px 8px' }}>{well.DeletedAt ? new Date(well.DeletedAt).toLocaleString() : '-'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            <div style={{ marginTop: 20, display: 'flex', justifyContent: 'flex-end' }}>
              <button 
                onClick={() => setShowPastWellsModal(false)} 
                style={{ background: '#ff9800', color: '#fff', border: 'none', borderRadius: 6, padding: '8px 18px', fontWeight: 600 }}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default DrillingDashboard;