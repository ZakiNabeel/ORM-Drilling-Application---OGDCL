import React, { Suspense } from 'react';
const { MapContainer, TileLayer, Marker, Popup } = require('react-leaflet');
require('leaflet/dist/leaflet.css');

function WellMap({ latitude, longitude, wellName, blockName }) {
  if (!latitude || !longitude) return null;
  return (
    <div style={{
      background: 'linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%)',
      borderRadius: '12px',
      padding: '20px',
      boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
      width: 340,
      height: 340,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
    }}>
      <h3 style={{
        marginBottom: '16px',
        color: '#1976d2',
        fontSize: '18px',
        fontWeight: 'bold',
        textAlign: 'center'
      }}>
        Well Location
      </h3>
      <Suspense fallback={<div>Loading map...</div>}>
        <MapContainer
          center={[latitude, longitude]}
          zoom={8}
          style={{ width: '100%', height: 250, borderRadius: 8 }}
          scrollWheelZoom={false}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url='https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'
          />
          <Marker position={[latitude, longitude]}>
            <Popup>
              {wellName}<br />
              {blockName}
            </Popup>
          </Marker>
        </MapContainer>
      </Suspense>
    </div>
  );
}

export default WellMap; 