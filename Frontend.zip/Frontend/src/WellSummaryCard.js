import React from 'react';

function WellSummaryCard({ op, onSelect }) {
  let isUpdatedToday = false;
  if (op.LastUpdated) {
    const today = new Date();
    const updated = new Date(op.LastUpdated);
    isUpdatedToday = updated.getFullYear() === today.getFullYear() && updated.getMonth() === today.getMonth() && updated.getDate() === today.getDate();
  }
  return (
    <div onClick={() => onSelect(op.WellName)} style={{ cursor: 'pointer', background: '#23234c', borderRadius: 14, padding: 24, color: '#fff', boxShadow: '0 4px 16px rgba(25, 118, 210, 0.10)', display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative', transition: 'box-shadow 0.2s', border: isUpdatedToday ? '2px solid #43ea7f' : '2px solid #ff5252', textAlign: 'center' }}>
      <div style={{ display: 'flex', alignItems: 'center', marginBottom: 12, justifyContent: 'center' }}>
        <div style={{ width: 16, height: 16, borderRadius: 4, background: isUpdatedToday ? '#43ea7f' : '#ff5252', marginRight: 12, border: '2px solid #fff' }}></div>
        <div style={{ fontWeight: 700, fontSize: 22 }}>{op.WellName}</div>
      </div>
      <div style={{ fontSize: 16, opacity: 0.8, marginBottom: 8, textAlign: 'center' }}>Block: <span style={{ color: '#fff' }}>{op.BlockName}</span></div>
      <div style={{ fontSize: 16, opacity: 0.8, marginBottom: 8, textAlign: 'center' }}>Present Depth: <span style={{ color: '#fff', fontWeight: 700, fontSize: '24px' }}>{op.PresentDepthM}</span></div>
      <div style={{ fontSize: 15, opacity: 0.7, marginTop: 8, fontStyle: 'italic', textAlign: 'center' }}>{op.PlanDetails}</div>
      <div style={{ position: 'absolute', top: 18, right: 24, fontSize: 13, fontWeight: 600, color: isUpdatedToday ? '#43ea7f' : '#ff5252' }}>
        {isUpdatedToday ? 'Updated Today' : 'Not Updated'}
      </div>
    </div>
  );
}

export default WellSummaryCard; 